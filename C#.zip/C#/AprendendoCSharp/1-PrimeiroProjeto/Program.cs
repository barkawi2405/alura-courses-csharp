﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace _1_PrimeiroProjeto
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Olá, mundo! Projeto no Visual Studio!");

            Console.WriteLine("A execução acabou. Tecle enter para finalizar...");
            Console.ReadLine();
        }
    }
}
