﻿using System;

namespace P12_CalculaPoupancaDois
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 12");

            double valorInvestido = 1000;
            for(int mes = 1; mes <= 12; mes++)
            {
                valorInvestido = valorInvestido * 1.0036;
                Console.WriteLine("Após " + mes + " você terá R$" + valorInvestido);
            }

            Console.ReadLine();
        }
    }
}
