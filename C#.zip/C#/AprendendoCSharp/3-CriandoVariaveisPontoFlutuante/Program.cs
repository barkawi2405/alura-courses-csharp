﻿using System;

namespace _3_CriandoVariaveisPontoFlutuante
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 3 Criando variáveis ponto flutuante");

            double salario = 1250.75;

            Console.WriteLine(salario);

            double idade = 15 / 2;

            Console.WriteLine("Marcelo tem " + idade);

            Console.WriteLine("A execução acabou. Tecle enter para sair.");
            Console.ReadLine();
        }
    }
}
