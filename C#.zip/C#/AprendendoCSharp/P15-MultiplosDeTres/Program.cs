﻿using System;

namespace P15_MultiplosDeTres
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 15");

            //Usando for
            for (int i = 3; i < 100; i += 3)
            {
              Console.WriteLine(i + " é um múltiplo de 3.");
            }

            //Usando while
            int contador = 99;
            while (contador > 0)
            {
                if (contador % 3 == 0)
                    Console.WriteLine(contador + " é um múltiplo de 3.");
                        
                contador -= 3;
            }

            Console.ReadLine();
        }
    }
}
