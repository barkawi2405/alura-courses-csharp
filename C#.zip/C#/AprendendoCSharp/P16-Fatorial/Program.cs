﻿using System;

namespace P16_Fatorial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 16");

            int fatorial = 1;
            for (int i = 1; i < 11; i++)
            {
                fatorial *= 1;
                Console.WriteLine("Fatorial de " + i + " = " + fatorial);
            }


            Console.ReadLine();
        }
    }
}
