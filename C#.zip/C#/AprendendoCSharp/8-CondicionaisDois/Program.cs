﻿using System;

namespace _7_Condicionais
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 8 - CondicionaisDois");

            int idadeEduardo = 18;
            //int quantidadePessoas = 2;
            //bool acompanhado = quantidadePessoas >= 2;
            bool acompanhado = false;

            if (idadeEduardo >= 18 && acompanhado == true)
            {
                Console.WriteLine("Eduardo pode entrar.");
            }
            else
            {
                Console.WriteLine("Eduardo não pode entrar.");
            }

            Console.ReadLine();
        }
    }
}
