﻿using System;

namespace _5_CaracteresETextos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando o projeto 5 - Caracteres e texto");

            //character
            char primeiraletra = ' ';
            Console.WriteLine(primeiraletra);

            primeiraletra = (char)65;
            Console.WriteLine(primeiraletra);

            primeiraletra = (char)(primeiraletra + 1);
            Console.WriteLine(primeiraletra);

            string titulo = "Alura Cursos de Tecnologia " + 2020;
            string cursosprogramacao = 
@"- .NET 
- Java 
- Javascript";
            Console.WriteLine(titulo);
            Console.WriteLine(cursosprogramacao);

            Console.ReadLine(); 
        }
    }
}
