﻿using System;

namespace P14_ForEncadeado
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 14");

            //Usando o break para este for
            for (int linha = 0; linha < 10; linha++)
            {
                for (int asterisco = 0; asterisco < 10; asterisco++)
                {
                    Console.Write("*");
                    if (asterisco >= linha)
                    {
                        break;
                    }
                }
                Console.WriteLine();
            }
            //Sem usar o break
            for (int linha = 0; linha < 10; linha++)
            {
                for (int asterisco = 0; asterisco <= linha; asterisco++)
                    Console.Write("*");
                
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
