﻿using System;

namespace _7_Condicionais
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 7 - Condicionais");

            int idadeEduardo = 17;
            int quantidadePessoas = 2;

            if (idadeEduardo >= 18)
            {
                Console.WriteLine("Eduardo é maior de idade, pode entrar.");
            }
            else
            {
                if (quantidadePessoas >= 2)
                {
                    Console.WriteLine("Eduardo é menor de idade, mas está acompanhado. Pode entrar.");
                }
                else
                {
                    Console.WriteLine("Eduardo é menor de idade, não pode entrar.");
                }
            }

            Console.ReadLine();
        }
    }
}
