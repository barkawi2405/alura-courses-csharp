﻿using System;

namespace P11_CalculoPoupanca
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 11 - Calculo poupança");

            double valorInvestido = 1000;
            int mes = 1;

            while (mes <= 12)
            {
                valorInvestido = valorInvestido * 1.0036;
                Console.WriteLine("Após " + mes + " mês você terá R$" + valorInvestido);
                mes++;
            }

            Console.ReadLine();
        }
    }
}
