﻿using System;

namespace _7_Condicionais
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 9 - Escopo");

            int idadeEduardo = 18;
            bool acompanhado = false;
            string mensagemAdicional;

            if (acompanhado == true)
            {
                mensagemAdicional = "Eduardo está acompanhado";
            }
            else
            {
                mensagemAdicional = "Eduardo está sozinho";
            }

            if (idadeEduardo >= 18 || acompanhado == true)
            {
                Console.WriteLine("Eduardo pode entrar.");
                Console.WriteLine(mensagemAdicional);
            }
            else
            {
                Console.WriteLine("Eduardo não pode entrar.");
                Console.WriteLine(mensagemAdicional);
            }

            Console.ReadLine();
        }
    }
}
