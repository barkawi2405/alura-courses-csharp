﻿using System;

namespace _4_ConversoesEOutrosTiposNumericos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando o projeto 4");

            double salario = 1200.50;

            // O int é uma variável que suporta valores até 32 bits.
            int salariointeiro = (int)salario;
            Console.WriteLine(salariointeiro);


            // O long é uma variável que suporta valores até 64 bits.
            long idadeuniverso = 13000000000;
            Console.WriteLine(idadeuniverso);


            // O short é uma variável que suporta valores até 16 bits.
            short quantidadeProdutos = 150;
            Console.WriteLine(quantidadeProdutos);

            float altura = 1.86f;
            Console.WriteLine(altura);

            Console.ReadLine();
        }   
    }
}
