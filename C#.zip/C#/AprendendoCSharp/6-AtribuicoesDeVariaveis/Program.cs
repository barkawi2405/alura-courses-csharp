﻿using System;

namespace _6_AtribuicoesDeVariaveis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando o projeto 6");

            int idade = 18;
            int idadeEduardo = idade;

            idade = 25;

            Console.WriteLine(idade);
            Console.WriteLine(idadeEduardo);

            Console.ReadLine();
        }
    }
}
