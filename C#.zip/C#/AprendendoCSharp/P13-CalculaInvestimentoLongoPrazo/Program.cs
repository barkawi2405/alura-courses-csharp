﻿using System;

namespace P13_CalculaInvestimentoLongoPrazo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Executando projeto 13");

            double valorInvestido = 1000;
            double rendimento = 1.0036;

            for (int ano = 1; ano <= 5; ano++)
            {
                for (int mes = 1; mes <= 12; mes++)
                {
                    valorInvestido *= rendimento;
                }
                rendimento += 0.0010;
            }

            Console.WriteLine("Ao término do investimento, você terá R$" + valorInvestido);

            Console.ReadLine();
        }
    }
}
