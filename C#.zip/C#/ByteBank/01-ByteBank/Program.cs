﻿using System;

namespace _01_ByteBank
{
    class Program
    {
        static void Main(string[] args)
        {

            ContaCorrente contaJoseCarlos = new ContaCorrente();


            contaJoseCarlos.titular = "José Carlos";
            contaJoseCarlos.agencia = 123;
            contaJoseCarlos.numero = 123001;
            contaJoseCarlos.saldo = 100;

            Console.WriteLine(contaJoseCarlos.titular);
            Console.WriteLine("Agência: " + contaJoseCarlos.agencia);
            Console.WriteLine("Número: " + contaJoseCarlos.numero);
            Console.WriteLine("Saldo: " + contaJoseCarlos.saldo);

            contaJoseCarlos.saldo += 200;
            Console.WriteLine("Saldo: " + contaJoseCarlos.saldo);

            Console.ReadLine();
        }
    }
}