﻿
public class ContaCorrente
{
    public string titular;
    public int agencia;
    public int numero;
    public double saldo;
}   
